import javax.swing.JOptionPane;

public class Carro extends Auto {

    public Carro(String marca, String ncarro, int ano) {
        super(marca,ncarro,ano);
        //TODO Auto-generated constructor stub
    }
     
    public void venda(){

        this.setMarca("Hilux");
        this.setNcarro("911");
        this.setAno(2014);

        JOptionPane.showMessageDialog(null,
            "A marca do carro é: " + this.getMarca() + 
            "\n O nome do carro é:"+ this.getNcarro() +
            "\n O ano é: " + this.getAno()
        );
    }
}
