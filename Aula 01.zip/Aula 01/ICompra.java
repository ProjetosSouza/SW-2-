public interface ICompra {
    public String compra();
    public double valor();
}
